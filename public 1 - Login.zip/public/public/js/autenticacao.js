document.addEventListener('DOMContentLoaded', function () {
    const formLogin = document.getElementById('login-form');
    const formRegistro = document.getElementById('registro-form');
    const formRecuperarSenha = document.getElementById('recuperar-form');

    // Função para validar o formato do e-mail
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    // Função para validar a senha
    function validatePassword(senha) {
        const re = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/; // Exige 8 caracteres, incluindo letras e números
        return re.test(senha);
    }

    if (formLogin) {
        formLogin.addEventListener('submit', function (e) {
            e.preventDefault();

            const email = document.getElementById('email').value;
            const senha = document.getElementById('senha').value;

            signInWithEmailAndPassword(auth, email, senha)
                .then(userCredential => {
                    alert('Login realizado com sucesso!');
                    window.location.href = 'painel.html'; // redireciona ao painel do usuário
                })
                .catch(error => {
                    console.error(error);
                    alert('Erro ao realizar login: ' + error.message);
                });
        });
    }

    if (formRegistro) {
        formRegistro.addEventListener('submit', function (e) {
            e.preventDefault();

            const email = document.getElementById('email').value;
            const senha = document.getElementById('senha').value;
            const confirmarSenha = document.getElementById('confirmar-senha').value;

            // Validar senhas
            const senhaError = document.getElementById('senha-error');
            const confirmarSenhaError = document.getElementById('confirmar-senha-error');
            senhaError.textContent = '';
            confirmarSenhaError.textContent = '';

            if (senha !== confirmarSenha) {
                confirmarSenhaError.textContent = 'As senhas não coincidem.';
                return;
            }

            if (!validatePassword(senha)) {
                senhaError.textContent = 'A senha deve ter no mínimo 8 caracteres, incluindo letras e números.';
                return;
            }

            if (!validateEmail(email)) {
                senhaError.textContent = 'Formato de e-mail inválido.';
                return;
            }

            createUserWithEmailAndPassword(auth, email, senha)
                .then(userCredential => {
                    alert('Registro realizado com sucesso!');
                    window.location.href = 'login.html'; // redireciona ao login após o registro
                })
                .catch(error => {
                    if (error.code === 'auth/email-already-in-use') {
                        alert('Esse e-mail já está em uso. Tente logar ou use outro e-mail.');
                    } else {
                        console.error(error);
                        alert('Erro ao realizar registro: ' + error.message);
                    }
                });
        });
    }

    if (formRecuperarSenha) {
        formRecuperarSenha.addEventListener('submit', function (e) {
            e.preventDefault();

            const email = document.getElementById('email').value;

            if (!validateEmail(email)) {
                alert('Formato de e-mail inválido.');
                return;
            }

            sendPasswordResetEmail(auth, email)
                .then(() => {
                    alert('E-mail de recuperação enviado com sucesso!');
                })
                .catch(error => {
                    console.error(error);
                    alert('Erro ao enviar e-mail de recuperação: ' + error.message);
                });
        });
    }
});
