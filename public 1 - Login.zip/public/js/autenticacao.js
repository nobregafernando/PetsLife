document.addEventListener('DOMContentLoaded', function () {
    const formLogin = document.getElementById('login-form');
    const formRegistro = document.getElementById('registro-form');
    const formRecuperarSenha = document.getElementById('recuperar-form');

    if (formLogin) {
        formLogin.addEventListener('submit', function (e) {
            e.preventDefault();

            const email = document.getElementById('email').value;
            const senha = document.getElementById('senha').value;

            firebase.auth().signInWithEmailAndPassword(email, senha)
                .then(userCredential => {
                    alert('Login realizado com sucesso!');
                    window.location.href = 'painel.html'; // redireciona ao painel do usuário
                })
                .catch(error => {
                    console.error(error);
                    alert('Erro ao realizar login: ' + error.message);
                });
        });
    }

    if (formRegistro) {
        formRegistro.addEventListener('submit', function (e) {
            e.preventDefault();

            const email = document.getElementById('email').value;
            const senha = document.getElementById('senha').value;

            firebase.auth().createUserWithEmailAndPassword(email, senha)
                .then(userCredential => {
                    alert('Registro realizado com sucesso!');
                    window.location.href = 'login.html'; // redireciona ao login após o registro
                })
                .catch(error => {
                    console.error(error);
                    alert('Erro ao realizar registro: ' + error.message);
                });
        });
    }

    if (formRecuperarSenha) {
        formRecuperarSenha.addEventListener('submit', function (e) {
            e.preventDefault();

            const email = document.getElementById('email').value;

            firebase.auth().sendPasswordResetEmail(email)
                .then(() => {
                    alert('E-mail de recuperação enviado com sucesso!');
                })
                .catch(error => {
                    console.error(error);
                    alert('Erro ao enviar e-mail de recuperação: ' + error.message);
                });
        });
    }
});

firebase.auth().createUserWithEmailAndPassword(email, password)
  .then((userCredential) => {
    // Sucesso
    alert("Conta criada com sucesso!");
    window.location.href = "login.html"; // Redireciona para a página de login
  })
  .catch((error) => {
    var errorMessage = error.message;
    alert("Erro: " + errorMessage);
  });
